#!/system/bin/sh
MODDIR=${0%/*}
LOGFILE=/data/adb/modules/caros-switcher/log.txt
CONFFILE=/sdcard/CarOS/config.env
STATEFILE=/data/adb/modules/caros-switcher/state.json

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $@" >> "$LOGFILE"; }
[ -f "$CONFFILE" ] && . "$CONFFILE"

: "${AUDI_BT_NAMES:=Audi}"
: "${AUDI_BT_MAC:=}"
: "${ALLOW_BT_IN_WIRED:=1}"
: "${DATA_OFF_OUTSIDE:=0}"
: "${IDLE_MAX_CPU_FREQ:=}"
: "${KIOSK_WHITELIST:=1}"
: "${WHITELIST_PACKAGES:=com.google.android.projection.gearhead,com.google.android.apps.maps,com.waze,com.spotify.music,com.google.android.apps.youtube.music}"
: "${LIMIT_QUICK_CHARGE_WIRED:=1}"
: "${VERBOSE:=1}"

vlog(){ [ "$VERBOSE" = "1" ] && log "[DBG]" "$@"; }

WL_PATTERN="$(echo "$WHITELIST_PACKAGES" | tr ',' '\n' | sed 's/[].[^$\\/*]/\\&/g' | paste -sd'|' -)"
[ -z "$WL_PATTERN" ] && WL_PATTERN="^$"

wifi_on(){ svc wifi enable; }
wifi_off(){ svc wifi disable; }
data_on(){ svc data enable; }
data_off(){ svc data disable; }
bt_on(){ cmd bluetooth enable >/dev/null 2>&1 || settings put global bluetooth_on 1; }
bt_off(){ cmd bluetooth disable >/dev/null 2>&1 || settings put global bluetooth_on 0; }

battery_saver_on(){ settings put global low_power 1; }
battery_saver_off(){ settings put global low_power 0; }

set_cpu_max(){
  MAX="$1"
  if [ -n "$MAX" ]; then
    for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
      [ -e "$cpu/cpufreq/scaling_max_freq" ] && echo "$MAX" > "$cpu/cpufreq/scaling_max_freq" 2>/dev/null
    done
  fi
}
reset_cpu_max(){
  for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
    if [ -e "$cpu/cpufreq/scaling_max_freq" ] && [ -e "$cpu/cpufreq/cpuinfo_max_freq" ]; then
      cat "$cpu/cpufreq/cpuinfo_max_freq" > "$cpu/cpufreq/scaling_max_freq" 2>/dev/null
    fi
  done
}

screen_off(){ input keyevent 26 >/dev/null 2>&1; }
screen_on(){ input keyevent 26 >/dev/null 2>&1; }

charge_limit_on(){
  for n in \
    /sys/class/power_supply/battery/charging_enabled \
    /sys/class/power_supply/battery/charge_enabled \
    /sys/class/power_supply/battery/charge_disable \
    /sys/class/power_supply/battery/input_suspend \
    /sys/class/power_supply/usb/input_current_limit \
    /sys/class/power_supply/battery/constant_charge_current_max \
    ; do
    if [ -e "$n" ]; then
      case "$n" in
        */input_current_limit|*/constant_charge_current_max)
          echo 500000 > "$n" 2>/dev/null && return 0 ;;
        *charging_enabled|*charge_enabled)
          echo 0 > "$n" 2>/dev/null && return 0 ;;
        *charge_disable|*input_suspend)
          echo 1 > "$n" 2>/dev/null && return 0 ;;
      esac
    fi
  done
  return 1
}
charge_limit_off(){
  for n in \
    /sys/class/power_supply/battery/charging_enabled \
    /sys/class/power_supply/battery/charge_enabled \
    /sys/class/power_supply/battery/charge_disable \
    /sys/class/power_supply/battery/input_suspend \
    /sys/class/power_supply/usb/input_current_limit \
    /sys/class/power_supply/battery/constant_charge_current_max \
    ; do
    if [ -e "$n" ]; then
      case "$n" in
        */input_current_limit|*/constant_charge_current_max)
          echo 3000000 > "$n" 2>/dev/null ;;
        *charging_enabled|*charge_enabled)
          echo 1 > "$n" 2>/dev/null ;;
        *charge_disable|*input_suspend)
          echo 0 > "$n" 2>/dev/null ;;
      esac
    fi
  done
  return 0
}

usb_connected(){
  if [ -f /sys/class/power_supply/usb/online ] && [ "$(cat /sys/class/power_supply/usb/online 2>/dev/null)" = "1" ]; then
    return 0
  fi
  dumpsys usb 2>/dev/null | grep -q "mConnected=true" && return 0
  return 1
}

aa_process_active(){
  pidof com.google.android.projection.gearhead >/dev/null 2>&1 && return 0
  dumpsys activity services 2>/dev/null | grep -qi com.google.android.projection.gearhead && return 0
  return 1
}

bt_connected_to_audi(){
  DUMP="$(dumpsys bluetooth_manager 2>/dev/null)"
  if [ -n "$AUDI_BT_MAC" ]; then
    echo "$DUMP" | grep -i "$AUDI_BT_MAC" | grep -qi "Connected" && return 0
  fi
  echo "$DUMP" | grep -Eiq "Name:.*(${AUDI_BT_NAMES})" && echo "$DUMP" | grep -qi "Connected: true" && return 0
  echo "$DUMP" | grep -Eiq "${AUDI_BT_NAMES}" && echo "$DUMP" | grep -qi "Connected" && return 0
  return 1
}

DISABLED_LIST_FILE="/data/adb/modules/caros-switcher/disabled_apps.list"

apply_kiosk_whitelist(){
  [ "$KIOSK_WHITELIST" = "1" ] || return 0
  MANDATORY="com.android.systemui|com.android.settings|com.google.android.projection.gearhead"
  PATTERN="($WL_PATTERN|$MANDATORY)"
  : > "$DISABLED_LIST_FILE"
  for pkg in $(pm list packages -3 | cut -d: -f2); do
    echo "$pkg" | grep -Eq "$PATTERN" && continue
    pm disable-user --user 0 "$pkg" >/dev/null 2>&1 && echo "$pkg" >> "$DISABLED_LIST_FILE"
  done
}

revert_kiosk_whitelist(){
  [ -f "$DISABLED_LIST_FILE" ] || return 0
  while read -r pkg; do
    [ -n "$pkg" ] && pm enable "$pkg" >/dev/null 2>&1
  done < "$DISABLED_LIST_FILE"
  rm -f "$DISABLED_LIST_FILE"
}

apply_wired_profile(){
  data_on
  if [ "$ALLOW_BT_IN_WIRED" = "1" ]; then bt_on; else bt_off; fi
  wifi_off
  battery_saver_off
  reset_cpu_max
  [ "$LIMIT_QUICK_CHARGE_WIRED" = "1" ] && charge_limit_on
  apply_kiosk_whitelist
  screen_off
}

apply_wireless_profile(){
  bt_on
  wifi_on
  data_on
  battery_saver_off
  reset_cpu_max
  charge_limit_off
  apply_kiosk_whitelist
  screen_off
}

apply_idle_profile(){
  wifi_off
  if [ "$DATA_OFF_OUTSIDE" = "1" ]; then data_off; else data_on; fi
  battery_saver_on
  set_cpu_max "$IDLE_MAX_CPU_FREQ"
  charge_limit_off
  revert_kiosk_whitelist
}

STATE=""
log "CarOS Profile Switcher service v0.2 started"

while true; do
  WIRED=0
  WIRELESS=0

  if usb_connected && aa_process_active; then
    WIRED=1
  elif bt_connected_to_audi && aa_process_active; then
    WIRELESS=1
  fi

  NEWSTATE="IDLE"
  if [ "$WIRED" = "1" ]; then
    NEWSTATE="WIRED"
  elif [ "$WIRELESS" = "1" ]; then
    NEWSTATE="WIRELESS"
  fi

  if [ "$NEWSTATE" != "$STATE" ]; then
    log "State change: $STATE -> $NEWSTATE"
    case "$NEWSTATE" in
      WIRED) apply_wired_profile ;;
      WIRELESS) apply_wireless_profile ;;
      IDLE) apply_idle_profile ;;
    esac
    STATE="$NEWSTATE"
  fi

  sleep 3
done
