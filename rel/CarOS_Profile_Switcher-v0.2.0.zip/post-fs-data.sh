#!/system/bin/sh
MODDIR=${0%/*}
LOGDIR=/data/adb/modules/caros-switcher
CONFDIR=/sdcard/CarOS
mkdir -p "$LOGDIR"
mkdir -p "$CONFDIR"

CONF="$CONFDIR/config.env"
if [ ! -f "$CONF" ]; then
  cat > "$CONF" <<'EOF'
# === CarOS Profile Switcher Configuration v0.2 ===

# Plusieurs noms BT possibles, séparés par | (regex), ex: "Audi|AUDI MMI|MyAudi"
AUDI_BT_NAMES="Audi"

# (Optionnel) Adresse MAC si tu préfères matcher par MAC
AUDI_BT_MAC=""

# Mode filaire : garder Bluetooth actif (1) ou l'éteindre (0)
ALLOW_BT_IN_WIRED=1

# Hors voiture : désactiver la data mobile (1) ou la laisser active (0)
DATA_OFF_OUTSIDE=0

# Limitation CPU hors voiture (en kHz). Laisse vide pour ne pas toucher.
# Exemple : 1516800 pour ~1.5 GHz.
IDLE_MAX_CPU_FREQ=

# Kiosk/Whitelist: 1 = activer, 0 = désactiver
KIOSK_WHITELIST=1

# Liste d'applis autorisées (packages), séparées par virgules.
# Ajoute ici tes apps AA/Maps/Musique. Le système et Android Auto restent autorisés d'office.
WHITELIST_PACKAGES="com.google.android.projection.gearhead,com.google.android.apps.maps,com.waze,com.spotify.music,com.google.android.apps.youtube.music"

# WIRED: limiter la charge rapide / réduire la chauffe (best effort). 1 = activer
LIMIT_QUICK_CHARGE_WIRED=1

# Logs verbeux
VERBOSE=1
EOF
  chmod 0644 "$CONF"
fi

chmod 0755 "$MODDIR/service.sh"
chmod 0755 "$MODDIR/post-fs-data.sh"
