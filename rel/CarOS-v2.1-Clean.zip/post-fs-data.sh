#!/system/bin/sh
MODDIR=${0%/*}
LOGDIR=/data/adb/modules/caros-switcher
CONFDIR=/sdcard/CarOS

# Attente que /sdcard soit monté (pour LineageOS)
for i in $(seq 1 30); do
  if [ -d "/sdcard" ] && [ -w "/sdcard" ]; then
    break
  fi
  sleep 1
done

mkdir -p "$LOGDIR"
mkdir -p "$CONFDIR" 2>/dev/null

CONF="$CONFDIR/config.env"
if [ ! -f "$CONF" ]; then
  # Vérification que /sdcard est bien accessible
  if [ -w "/sdcard" ]; then
  cat > "$CONF" <<'EOF'
# === CarOS Profile Switcher Configuration v0.2 ===

# Plusieurs noms BT possibles, séparés par | (regex), ex: "Audi|AUDI MMI|MyAudi"
AUDI_BT_NAMES="Audi"

# (Optionnel) Adresse MAC si tu préfères matcher par MAC
AUDI_BT_MAC=""

# Mode filaire : garder Bluetooth actif (1) ou l'éteindre (0)
ALLOW_BT_IN_WIRED=1

# Hors voiture : désactiver la data mobile (1) ou la laisser active (0)
DATA_OFF_OUTSIDE=0

# Limitation CPU hors voiture (en kHz). Laisse vide pour ne pas toucher.
# Exemple : 1516800 pour ~1.5 GHz.
IDLE_MAX_CPU_FREQ=

# WIRED: limiter la charge rapide / réduire la chauffe (best effort). 1 = activer
LIMIT_QUICK_CHARGE_WIRED=1

# Logs verbeux
VERBOSE=1
EOF
  chmod 0644 "$CONF"
  else
    # Si /sdcard n'est pas accessible, on laisse service.sh s'en charger
    echo "$(date) [post-fs-data] /sdcard not writable, config will be created by service.sh" >> "$LOGDIR/log.txt"
  fi
fi

chmod 0755 "$MODDIR/service.sh"
chmod 0755 "$MODDIR/post-fs-data.sh"
